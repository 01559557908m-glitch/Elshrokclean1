
import { pgTable, text, serial, integer, boolean, timestamp, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(), // Phone number for customers, "admin" for admin
  password: text("password"), // Only for admin
  role: text("role").notNull().default("customer"), // "admin" | "customer"
  name: text("name"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const items = pgTable("items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(), // "Clothes", "Bedding", etc.
  basePrice: numeric("base_price").notNull(),
  isVariable: boolean("is_variable").default(false), // true if needs pricing (photo)
  description: text("description"),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(), // Link to users.id
  status: text("status").notNull().default("pending_pricing"), // pending_pricing, washing, ready, completed
  totalPrice: numeric("total_price"),
  estimatedFinish: timestamp("estimated_finish"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  name: text("name").notNull(), // Snapshot of item name or "Custom Item"
  quantity: integer("quantity").notNull().default(1),
  price: numeric("price"), // Price per unit
  imageUrl: text("image_url"), // For variable items
  notes: text("notes"),
});

export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  isOpen: boolean("is_open").default(true),
  workingHours: text("working_hours").default("9:00 AM - 10:00 PM"),
  locationUrl: text("location_url").default("https://maps.google.com"),
  announcement: text("announcement"), // Optional banner text
});

// Zod Schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertItemSchema = createInsertSchema(items).omit({ id: true });
export const insertOrderSchema = createInsertSchema(orders).omit({ id: true, createdAt: true });
export const insertOrderItemSchema = createInsertSchema(orderItems).omit({ id: true });
export const insertSettingsSchema = createInsertSchema(settings).omit({ id: true });

// Types
export type User = typeof users.$inferSelect;
export type Item = typeof items.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type OrderItem = typeof orderItems.$inferSelect;
export type Settings = typeof settings.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertItem = z.infer<typeof insertItemSchema>;
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type InsertOrderItem = z.infer<typeof insertOrderItemSchema>;
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
