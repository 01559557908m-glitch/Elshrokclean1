
import { z } from "zod";
import { insertUserSchema, insertItemSchema, insertOrderSchema, insertOrderItemSchema, insertSettingsSchema, users, items, orders, orderItems, settings } from "./schema";

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

// Composite types for API
export const createOrderWithItemsSchema = z.object({
  userId: z.number(),
  items: z.array(z.object({
    name: z.string(),
    quantity: z.number(),
    price: z.string().optional(), // Optional if variable
    imageUrl: z.string().optional(),
    notes: z.string().optional(),
  }))
});

export const api = {
  auth: {
    login: {
      method: "POST" as const,
      path: "/api/auth/login" as const,
      input: z.object({
        username: z.string(),
        password: z.string().optional(), // For admin
        isOtp: z.boolean().optional(), // For customer
      }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.internal,
      },
    },
    register: {
      method: "POST" as const,
      path: "/api/auth/register" as const,
      input: insertUserSchema,
      responses: {
        201: z.custom<typeof users.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  settings: {
    get: {
      method: "GET" as const,
      path: "/api/settings" as const,
      responses: {
        200: z.custom<typeof settings.$inferSelect>(),
      },
    },
    update: {
      method: "PUT" as const,
      path: "/api/settings" as const,
      input: insertSettingsSchema.partial(),
      responses: {
        200: z.custom<typeof settings.$inferSelect>(),
      },
    },
  },
  items: {
    list: {
      method: "GET" as const,
      path: "/api/items" as const,
      responses: {
        200: z.array(z.custom<typeof items.$inferSelect>()),
      },
    },
    create: {
      method: "POST" as const,
      path: "/api/items" as const,
      input: insertItemSchema,
      responses: {
        201: z.custom<typeof items.$inferSelect>(),
      },
    },
    update: {
      method: "PUT" as const,
      path: "/api/items/:id" as const,
      input: insertItemSchema.partial(),
      responses: {
        200: z.custom<typeof items.$inferSelect>(),
      },
    },
    delete: {
      method: "DELETE" as const,
      path: "/api/items/:id" as const,
      responses: {
        204: z.void(),
      },
    },
  },
  orders: {
    list: {
      method: "GET" as const,
      path: "/api/orders" as const,
      input: z.object({ userId: z.string().optional() }).optional(), // Optional filter by user
      responses: {
        200: z.array(z.custom<typeof orders.$inferSelect & { items: typeof orderItems.$inferSelect[] }>()),
      },
    },
    get: {
      method: "GET" as const,
      path: "/api/orders/:id" as const,
      responses: {
        200: z.custom<typeof orders.$inferSelect & { items: typeof orderItems.$inferSelect[] }>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: "POST" as const,
      path: "/api/orders" as const,
      input: createOrderWithItemsSchema,
      responses: {
        201: z.custom<typeof orders.$inferSelect>(),
      },
    },
    update: {
      method: "PUT" as const,
      path: "/api/orders/:id" as const,
      input: insertOrderSchema.partial(),
      responses: {
        200: z.custom<typeof orders.$inferSelect>(),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
