
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api, createOrderWithItemsSchema } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // --- Auth Routes ---
  app.post(api.auth.login.path, async (req, res) => {
    const { username, password, isOtp } = req.body;
    
    let user = await storage.getUserByUsername(username);

    if (username === "admin") {
      if (password === "emad1342") {
        if (!user) {
          user = await storage.createUser({ username: "admin", role: "admin", name: "Owner" });
        }
        return res.json(user);
      } else {
        return res.status(401).json({ message: "Invalid password" });
      }
    }

    // Customer Login (Simulated OTP)
    if (!user) {
      // Auto-register customer for MVP if they don't exist
      user = await storage.createUser({ username, role: "customer", name: "Customer " + username });
    }
    res.json(user);
  });

  app.post(api.auth.register.path, async (req, res) => {
    try {
      const input = api.auth.register.input.parse(req.body);
      const existing = await storage.getUserByUsername(input.username);
      if (existing) {
        return res.status(400).json({ message: "User already exists" });
      }
      const user = await storage.createUser(input);
      res.status(201).json(user);
    } catch (err) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  // --- Settings Routes ---
  app.get(api.settings.get.path, async (req, res) => {
    const settings = await storage.getSettings();
    res.json(settings);
  });

  app.put(api.settings.update.path, async (req, res) => {
    const settings = await storage.updateSettings(req.body);
    res.json(settings);
  });

  // --- Items Routes ---
  app.get(api.items.list.path, async (req, res) => {
    const items = await storage.getItems();
    res.json(items);
  });

  app.post(api.items.create.path, async (req, res) => {
    const item = await storage.createItem(req.body);
    res.status(201).json(item);
  });

  app.put(api.items.update.path, async (req, res) => {
    const item = await storage.updateItem(Number(req.params.id), req.body);
    res.json(item);
  });

  app.delete(api.items.delete.path, async (req, res) => {
    await storage.deleteItem(Number(req.params.id));
    res.status(204).send();
  });

  // --- Orders Routes ---
  app.get(api.orders.list.path, async (req, res) => {
    const userId = req.query.userId ? Number(req.query.userId) : undefined;
    const orders = await storage.getOrders(userId);
    res.json(orders);
  });

  app.get(api.orders.get.path, async (req, res) => {
    const order = await storage.getOrder(Number(req.params.id));
    if (!order) return res.status(404).json({ message: "Order not found" });
    res.json(order);
  });

  app.post(api.orders.create.path, async (req, res) => {
    try {
      const { userId, items } = createOrderWithItemsSchema.parse(req.body);
      
      // Calculate initial total for fixed price items
      let total = 0;
      // We will trust the frontend/DB price match for now or calculate simply
      // For MVP, we set total to 0 if there are variable items, or sum of known prices
      
      const order = await storage.createOrder({ 
        userId, 
        totalPrice: "0", // Will be updated by admin or calculation
        status: "pending_pricing" 
      }, items);
      
      res.status(201).json(order);
    } catch (err) {
      console.error(err);
      res.status(400).json({ message: "Invalid order data" });
    }
  });

  app.put(api.orders.update.path, async (req, res) => {
    const order = await storage.updateOrder(Number(req.params.id), req.body);
    res.json(order);
  });

  // Seed Data
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const items = await storage.getItems();
  if (items.length === 0) {
    console.log("Seeding items...");
    await storage.createItem({ name: "Shirt", category: "Clothes", basePrice: "25", isVariable: false });
    await storage.createItem({ name: "T-Shirt", category: "Clothes", basePrice: "15", isVariable: false });
    await storage.createItem({ name: "Jeans", category: "Clothes", basePrice: "30", isVariable: false });
    await storage.createItem({ name: "Bedsheet (Single)", category: "Bedding", basePrice: "40", isVariable: false });
    await storage.createItem({ name: "Bedsheet (Double)", category: "Bedding", basePrice: "60", isVariable: false });
    await storage.createItem({ name: "Blanket", category: "Bedding", basePrice: "0", isVariable: true }); // Variable price
    
    // Create Admin if not exists
    await storage.createUser({ username: "admin", role: "admin", name: "Owner" });
  }
}
