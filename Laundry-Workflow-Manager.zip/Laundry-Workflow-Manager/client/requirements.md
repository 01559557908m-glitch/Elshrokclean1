## Packages
framer-motion | Animations for page transitions and micro-interactions
lucide-react | Icons for the UI
date-fns | Formatting dates and times

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Outfit', sans-serif"],
  body: ["'DM Sans', sans-serif"],
}
