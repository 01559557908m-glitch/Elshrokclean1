import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { api, type User } from '@shared/routes';
import { useToast } from './use-toast';

// Simple client-side auth state for MVP
// In a real app, this would be handled by http-only cookies and /api/me endpoint

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  login: (user: User) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      login: (user) => set({ user, isAuthenticated: true }),
      logout: () => set({ user: null, isAuthenticated: false }),
    }),
    {
      name: 'auth-storage',
    }
  )
);

export function useLogin() {
  const { toast } = useToast();
  const loginStore = useAuthStore((state) => state.login);

  return useMutation({
    mutationFn: async (credentials: { username: string; password?: string; isOtp?: boolean }) => {
      const res = await fetch(api.auth.login.path, {
        method: api.auth.login.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(credentials),
      });
      
      if (!res.ok) {
        if (res.status === 401) throw new Error('Invalid credentials');
        throw new Error('Login failed');
      }
      
      return api.auth.login.responses[200].parse(await res.json());
    },
    onSuccess: (user) => {
      loginStore(user);
      toast({
        title: "Welcome back!",
        description: `Logged in as ${user.name || user.username}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Login Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}

export function useRegister() {
  const { toast } = useToast();
  const loginStore = useAuthStore((state) => state.login);

  return useMutation({
    mutationFn: async (data: any) => {
      const res = await fetch(api.auth.register.path, {
        method: api.auth.register.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || 'Registration failed');
      }

      return api.auth.register.responses[201].parse(await res.json());
    },
    onSuccess: (user) => {
      loginStore(user);
      toast({
        title: "Account Created",
        description: "Welcome to Al-Shorouk Clean!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Registration Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}
