import { useSettings } from "@/hooks/use-settings";
import { MapPin } from "lucide-react";

export function Header() {
  const { data: settings } = useSettings();

  const isOpen = settings?.isOpen ?? false;

  return (
    <header className="bg-white border-b border-slate-100 sticky top-0 z-40 shadow-sm/50">
      <div className="mobile-container h-16 flex items-center justify-between">
        <div className="flex flex-col">
          <h1 className="text-xl font-display font-bold text-primary tracking-tight">
            Al-Shorouk <span className="text-slate-900">Clean</span>
          </h1>
          <div className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
            <span className={isOpen ? "text-green-600" : "text-red-500"}>
              {isOpen ? "Open Now" : "Closed"}
            </span>
            <span>•</span>
            <span>{settings?.workingHours || "9 AM - 10 PM"}</span>
          </div>
        </div>

        {settings?.locationUrl && (
          <a
            href={settings.locationUrl}
            target="_blank"
            rel="noreferrer"
            className="p-2 bg-slate-50 hover:bg-slate-100 rounded-full text-slate-600 transition-colors"
          >
            <MapPin className="w-5 h-5" />
          </a>
        )}
      </div>
    </header>
  );
}
