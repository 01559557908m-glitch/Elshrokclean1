import { Link, useLocation } from "wouter";
import { Home, Shirt, ShoppingBag, User } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuthStore } from "@/hooks/use-auth";

export function BottomNav() {
  const [location] = useLocation();
  const { user } = useAuthStore();

  const isAdmin = user?.role === "admin";

  const navItems = [
    { href: "/", icon: Home, label: "Home" },
    { href: "/prices", icon: Shirt, label: "Prices" },
    // Show Dashboard link for admins, Orders link for customers, nothing if logged out (redirects to login)
    ...(isAdmin 
      ? [{ href: "/admin", icon: ShoppingBag, label: "Admin" }] 
      : [{ href: "/orders", icon: ShoppingBag, label: "My Orders" }]
    ),
    { href: "/profile", icon: User, label: "Profile" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-100 pb-safe shadow-lg z-50">
      <div className="flex justify-around items-center h-16 max-w-md mx-auto px-2">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href} className={cn(
              "flex flex-col items-center justify-center w-full h-full space-y-1 transition-colors duration-200",
              isActive ? "text-primary" : "text-slate-400 hover:text-slate-600"
            )}>
              <item.icon className={cn("w-6 h-6", isActive && "fill-current/10")} strokeWidth={isActive ? 2.5 : 2} />
              <span className="text-[10px] font-medium">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
