import { cn } from "@/lib/utils";

type Status = "pending_pricing" | "washing" | "ready" | "completed";

const statusConfig: Record<Status, { label: string; className: string }> = {
  pending_pricing: {
    label: "Pricing",
    className: "bg-amber-100 text-amber-700 border-amber-200",
  },
  washing: {
    label: "Washing",
    className: "bg-blue-100 text-blue-700 border-blue-200",
  },
  ready: {
    label: "Ready",
    className: "bg-green-100 text-green-700 border-green-200",
  },
  completed: {
    label: "Done",
    className: "bg-slate-100 text-slate-600 border-slate-200",
  },
};

export function StatusBadge({ status }: { status: string }) {
  const config = statusConfig[status as Status] || statusConfig.pending_pricing;

  return (
    <span className={cn(
      "px-2.5 py-1 rounded-full text-xs font-semibold border",
      config.className
    )}>
      {config.label}
    </span>
  );
}
