import { useState } from "react";
import { useAuthStore, useLogin, useRegister } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserSchema, type InsertUser } from "@shared/schema";
import { LogOut, User as UserIcon, Shield } from "lucide-react";
import { z } from "zod";

export default function Profile() {
  const { user, logout } = useAuthStore();
  const [activeTab, setActiveTab] = useState("login");
  
  if (user) {
    return (
      <div className="min-h-screen bg-slate-50 p-6 flex flex-col items-center justify-center">
        <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-6 text-primary">
          <UserIcon className="w-10 h-10" />
        </div>
        <h2 className="text-2xl font-display font-bold mb-1">{user.name || user.username}</h2>
        <p className="text-slate-500 mb-8 capitalize">{user.role} Account</p>
        
        <Button variant="outline" className="w-full max-w-xs gap-2" onClick={logout}>
          <LogOut className="w-4 h-4" />
          Log Out
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl p-6 sm:p-8">
        <div className="text-center mb-8">
          <h1 className="text-2xl font-display font-bold text-primary mb-2">Welcome Back</h1>
          <p className="text-slate-500 text-sm">Login to manage your laundry orders</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="login">Login</TabsTrigger>
            <TabsTrigger value="register">Sign Up</TabsTrigger>
          </TabsList>
          
          <TabsContent value="login">
            <LoginForm />
          </TabsContent>
          
          <TabsContent value="register">
            <RegisterForm onSuccess={() => setActiveTab("login")} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function LoginForm() {
  const login = useLogin();
  const [isAdmin, setIsAdmin] = useState(false);
  
  const formSchema = z.object({
    username: z.string().min(1, "Required"),
    password: z.string().optional(),
  });

  const { register, handleSubmit, formState: { errors } } = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
  });

  const onSubmit = (data: any) => {
    login.mutate({
      username: data.username,
      password: isAdmin ? data.password : undefined,
      isOtp: !isAdmin
    });
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div className="space-y-2">
        <label className="text-sm font-medium text-slate-700">
          {isAdmin ? "Username" : "Phone Number"}
        </label>
        <Input 
          {...register("username")} 
          placeholder={isAdmin ? "admin" : "01xxxxxxxxx"} 
          type={isAdmin ? "text" : "tel"}
        />
        {errors.username && <p className="text-xs text-red-500">{errors.username.message}</p>}
      </div>

      {isAdmin && (
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700">Password</label>
          <Input 
            {...register("password")} 
            type="password" 
            placeholder="••••••"
          />
        </div>
      )}

      <Button className="w-full" disabled={login.isPending}>
        {login.isPending ? "Logging in..." : (isAdmin ? "Login as Admin" : "Send OTP")}
      </Button>

      <div className="text-center">
        <button
          type="button"
          onClick={() => setIsAdmin(!isAdmin)}
          className="text-xs text-slate-400 hover:text-slate-600 flex items-center justify-center gap-1 mx-auto mt-4"
        >
          <Shield className="w-3 h-3" />
          {isAdmin ? "Switch to Customer Login" : "Admin Login"}
        </button>
      </div>
    </form>
  );
}

function RegisterForm({ onSuccess }: { onSuccess: () => void }) {
  const registerMut = useRegister();
  
  const { register, handleSubmit, formState: { errors } } = useForm<InsertUser>({
    resolver: zodResolver(insertUserSchema),
    defaultValues: { role: "customer" }
  });

  const onSubmit = (data: InsertUser) => {
    registerMut.mutate(data, {
      onSuccess: () => onSuccess(),
    });
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div className="space-y-2">
        <label className="text-sm font-medium text-slate-700">Full Name</label>
        <Input {...register("name")} placeholder="Your Name" />
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium text-slate-700">Phone Number</label>
        <Input {...register("username")} placeholder="01xxxxxxxxx" type="tel" />
        {errors.username && <p className="text-xs text-red-500">{errors.username.message}</p>}
      </div>

      <Button className="w-full" disabled={registerMut.isPending}>
        {registerMut.isPending ? "Creating Account..." : "Create Account"}
      </Button>
    </form>
  );
}
