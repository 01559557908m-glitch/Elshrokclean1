import { Header } from "@/components/Header";
import { useOrders } from "@/hooks/use-orders";
import { useAuthStore } from "@/hooks/use-auth";
import { StatusBadge } from "@/components/StatusBadge";
import { Link, useLocation } from "wouter";
import { Loader2, PackageOpen } from "lucide-react";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";

export default function Orders() {
  const { user } = useAuthStore();
  const [, setLocation] = useLocation();
  const { data: orders, isLoading } = useOrders(user?.id);

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-slate-50 text-center">
        <PackageOpen className="w-12 h-12 text-slate-300 mb-4" />
        <h2 className="text-xl font-bold mb-2">Please Login</h2>
        <p className="text-slate-500 mb-6">You need to be logged in to view your orders.</p>
        <Button onClick={() => setLocation("/profile")}>Go to Login</Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <main className="mobile-container py-6 space-y-6">
        <h2 className="text-2xl font-display font-bold">My Orders</h2>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
          </div>
        ) : !orders || orders.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl border border-slate-100 shadow-sm">
            <PackageOpen className="w-12 h-12 text-slate-200 mx-auto mb-3" />
            <h3 className="font-medium text-slate-900">No orders yet</h3>
            <p className="text-sm text-slate-500 mt-1">Make your first request today!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order) => (
              <div key={order.id} className="bg-white rounded-xl p-5 border border-slate-100 shadow-sm">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <div className="text-xs text-slate-400 mb-1">Order #{order.id}</div>
                    <div className="font-display font-bold text-lg">
                      {order.totalPrice ? `${order.totalPrice} EGP` : 'Pending Quote'}
                    </div>
                  </div>
                  <StatusBadge status={order.status} />
                </div>
                
                <div className="space-y-2 mb-4">
                  {order.items?.map((item: any) => (
                    <div key={item.id} className="text-sm text-slate-600 flex justify-between">
                      <span>{item.quantity}x {item.name}</span>
                      {item.price && <span className="text-slate-400">{item.price} EGP</span>}
                    </div>
                  ))}
                </div>

                <div className="pt-4 border-t border-slate-50 flex justify-between items-center">
                  <span className="text-xs text-slate-400">
                    {format(new Date(order.createdAt!), "MMM d, yyyy")}
                  </span>
                  {order.estimatedFinish && (
                    <span className="text-xs font-medium text-primary bg-blue-50 px-2 py-1 rounded">
                      Ready by {format(new Date(order.estimatedFinish), "EEE, h a")}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
