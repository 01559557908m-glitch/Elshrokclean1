import { useState } from "react";
import { useAuthStore } from "@/hooks/use-auth";
import { useOrders, useUpdateOrder } from "@/hooks/use-orders";
import { useItems, useCreateItem, useUpdateItem, useDeleteItem } from "@/hooks/use-items";
import { useSettings, useUpdateSettings } from "@/hooks/use-settings";
import { Link } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { StatusBadge } from "@/components/StatusBadge";
import { Dialog, DialogContent, DialogTrigger, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Plus, Edit, Trash2, Save, X } from "lucide-react";
import { format } from "date-fns";
import { Item, Order } from "@shared/schema";

export default function Admin() {
  const { user } = useAuthStore();

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center p-6">
          <h2 className="text-xl font-bold text-red-600 mb-2">Access Denied</h2>
          <p className="text-slate-500 mb-4">You do not have permission to view this page.</p>
          <Link href="/">
            <Button>Go Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="bg-white border-b border-slate-100 p-4 sticky top-0 z-10">
        <h1 className="text-xl font-display font-bold text-slate-900">Admin Dashboard</h1>
      </div>

      <div className="p-4 sm:p-6 max-w-4xl mx-auto">
        <Tabs defaultValue="orders">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="prices">Prices</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="orders">
            <OrdersManager />
          </TabsContent>

          <TabsContent value="prices">
            <PricesManager />
          </TabsContent>

          <TabsContent value="settings">
            <SettingsManager />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function OrdersManager() {
  const { data: orders, isLoading } = useOrders();
  const updateOrder = useUpdateOrder();
  const [editingId, setEditingId] = useState<number | null>(null);
  
  // State for edit form
  const [totalPrice, setTotalPrice] = useState("");
  const [status, setStatus] = useState("");
  
  if (isLoading) return <Loader2 className="w-8 h-8 animate-spin mx-auto text-primary" />;

  const startEdit = (order: Order) => {
    setEditingId(order.id);
    setTotalPrice(order.totalPrice?.toString() || "");
    setStatus(order.status);
  };

  const handleSave = async (id: number) => {
    await updateOrder.mutateAsync({
      id,
      totalPrice: totalPrice,
      status: status,
      estimatedFinish: new Date(Date.now() + 24*60*60*1000) // Mock +24h
    });
    setEditingId(null);
  };

  return (
    <div className="space-y-4">
      {orders?.map(order => (
        <div key={order.id} className="bg-white rounded-xl p-4 shadow-sm border border-slate-100">
          <div className="flex justify-between items-start mb-4">
            <div>
              <div className="font-bold text-slate-900">Order #{order.id}</div>
              <div className="text-xs text-slate-500">
                {format(new Date(order.createdAt!), "PP p")}
              </div>
            </div>
            {editingId === order.id ? (
              <Button size="sm" onClick={() => handleSave(order.id)} disabled={updateOrder.isPending}>
                <Save className="w-4 h-4 mr-1" /> Save
              </Button>
            ) : (
              <Button size="sm" variant="ghost" onClick={() => startEdit(order)}>
                <Edit className="w-4 h-4" />
              </Button>
            )}
          </div>

          {/* Items */}
          <div className="bg-slate-50 rounded-lg p-3 mb-4 text-sm space-y-2">
            {order.items?.map((item: any) => (
              <div key={item.id} className="flex justify-between">
                <span>
                  {item.quantity}x {item.name}
                  {item.notes && <span className="block text-xs text-slate-400 italic">"{item.notes}"</span>}
                </span>
                {item.imageUrl && (
                  <a href={item.imageUrl} target="_blank" className="text-blue-500 text-xs underline">View Photo</a>
                )}
              </div>
            ))}
          </div>

          {/* Controls */}
          <div className="flex items-center gap-4 pt-3 border-t border-slate-100">
            <div className="flex-1">
              <label className="text-xs font-medium text-slate-500 block mb-1">Status</label>
              {editingId === order.id ? (
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending_pricing">Pending Pricing</SelectItem>
                    <SelectItem value="washing">Washing</SelectItem>
                    <SelectItem value="ready">Ready</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              ) : (
                <StatusBadge status={order.status} />
              )}
            </div>

            <div className="flex-1">
              <label className="text-xs font-medium text-slate-500 block mb-1">Total Price (EGP)</label>
              {editingId === order.id ? (
                <Input 
                  className="h-8 text-xs" 
                  type="number" 
                  value={totalPrice} 
                  onChange={e => setTotalPrice(e.target.value)} 
                />
              ) : (
                <span className="font-bold text-slate-900">{order.totalPrice || "—"}</span>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function PricesManager() {
  const { data: items, isLoading } = useItems();
  const createItem = useCreateItem();
  const updateItem = useUpdateItem();
  const deleteItem = useDeleteItem();
  
  const [newItem, setNewItem] = useState({ name: "", category: "Clothes", basePrice: "0" });
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  if (isLoading) return <Loader2 className="w-8 h-8 animate-spin mx-auto text-primary" />;

  const handleCreate = async () => {
    await createItem.mutateAsync(newItem);
    setIsDialogOpen(false);
    setNewItem({ name: "", category: "Clothes", basePrice: "0" });
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-2">
              <Plus className="w-4 h-4" /> Add Item
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Item</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <Input 
                placeholder="Item Name" 
                value={newItem.name} 
                onChange={e => setNewItem({...newItem, name: e.target.value})} 
              />
              <Select 
                value={newItem.category} 
                onValueChange={v => setNewItem({...newItem, category: v})}
              >
                <SelectTrigger><SelectValue placeholder="Category" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Clothes">Clothes</SelectItem>
                  <SelectItem value="Bedding">Bedding</SelectItem>
                  <SelectItem value="Curtains">Curtains</SelectItem>
                </SelectContent>
              </Select>
              <Input 
                type="number" 
                placeholder="Base Price" 
                value={newItem.basePrice} 
                onChange={e => setNewItem({...newItem, basePrice: e.target.value})} 
              />
              <Button onClick={handleCreate} disabled={createItem.isPending}>Create</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="bg-white rounded-xl border border-slate-100 overflow-hidden">
        {items?.map(item => (
          <div key={item.id} className="p-4 border-b border-slate-100 last:border-0 flex justify-between items-center">
            <div>
              <div className="font-medium">{item.name}</div>
              <div className="text-xs text-slate-500">{item.category}</div>
            </div>
            <div className="flex items-center gap-4">
              <span className="font-bold text-slate-700">{item.basePrice} EGP</span>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 text-red-500 hover:text-red-600 hover:bg-red-50"
                onClick={() => deleteItem.mutate(item.id)}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function SettingsManager() {
  const { data: settings, isLoading } = useSettings();
  const updateSettings = useUpdateSettings();

  const [isOpen, setIsOpen] = useState(settings?.isOpen ?? true);
  const [hours, setHours] = useState(settings?.workingHours ?? "");

  const handleSave = () => {
    updateSettings.mutate({ 
      isOpen, 
      workingHours: hours 
    });
  };

  if (isLoading) return <Loader2 className="w-8 h-8 animate-spin mx-auto text-primary" />;

  return (
    <div className="bg-white rounded-xl border border-slate-100 p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-0.5">
          <label className="font-medium text-slate-900">Shop Status</label>
          <p className="text-xs text-slate-500">Turn off to show "Closed" badge</p>
        </div>
        <Switch checked={isOpen} onCheckedChange={setIsOpen} />
      </div>

      <div className="space-y-2">
        <label className="font-medium text-slate-900">Working Hours</label>
        <Input 
          value={hours} 
          onChange={e => setHours(e.target.value)} 
          placeholder="e.g. 9:00 AM - 10:00 PM"
        />
      </div>

      <Button className="w-full" onClick={handleSave} disabled={updateSettings.isPending}>
        {updateSettings.isPending ? "Saving..." : "Save Settings"}
      </Button>
    </div>
  );
}
