import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, Sparkles, Clock, Shirt } from "lucide-react";
import { useAuthStore } from "@/hooks/use-auth";
import { useOrders } from "@/hooks/use-orders";
import { StatusBadge } from "@/components/StatusBadge";
import { format } from "date-fns";

export default function Home() {
  const { user } = useAuthStore();
  const { data: orders } = useOrders(user?.id);

  // Get only active orders (not completed)
  const activeOrders = orders?.filter(o => o.status !== 'completed').slice(0, 2);

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <main className="mobile-container py-6 space-y-8">
        {/* Welcome Section */}
        <div className="bg-gradient-to-br from-primary to-blue-600 rounded-2xl p-6 text-white shadow-lg shadow-blue-500/20 relative overflow-hidden">
          {/* Decorative circles */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-10 -mt-10 blur-2xl" />
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-10 -mb-10 blur-xl" />
          
          <div className="relative z-10">
            <h2 className="text-2xl font-display font-bold mb-2">
              Fresh & Clean, <br /> Just for You.
            </h2>
            <p className="text-blue-100 text-sm mb-6 max-w-[200px]">
              Professional laundry service with quick pickup and delivery.
            </p>
            
            <Link href="/prices">
              <Button variant="secondary" className="font-semibold text-blue-700 hover:text-blue-800">
                Check Prices <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>

        {/* Active Orders Section - Only if logged in */}
        {user && activeOrders && activeOrders.length > 0 && (
          <section>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-lg font-bold">Active Orders</h3>
              <Link href="/orders" className="text-xs font-medium text-primary hover:underline">
                View All
              </Link>
            </div>
            
            <div className="space-y-3">
              {activeOrders.map(order => (
                <Link key={order.id} href={`/orders/${order.id}`}>
                  <div className="bg-white rounded-xl p-4 border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <span className="text-xs text-slate-400 font-mono">#{order.id.toString().padStart(4, '0')}</span>
                        <div className="text-sm font-semibold mt-0.5">
                          {order.items?.length || 0} Items
                        </div>
                      </div>
                      <StatusBadge status={order.status} />
                    </div>
                    
                    {order.estimatedFinish && (
                      <div className="flex items-center text-xs text-slate-500 bg-slate-50 p-2 rounded-lg">
                        <Clock className="w-3.5 h-3.5 mr-2 text-primary" />
                        Estimated: {format(new Date(order.estimatedFinish), "MMM d, h:mm a")}
                      </div>
                    )}
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* Features Grid */}
        <section className="grid grid-cols-2 gap-4">
          <Link href="/prices">
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm hover:border-primary/20 transition-colors flex flex-col items-center text-center space-y-3">
              <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center text-primary">
                <Shirt className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-sm">Ironing Only</h4>
                <p className="text-xs text-slate-400 mt-1">Starting from 5 EGP</p>
              </div>
            </div>
          </Link>
          
          <Link href="/prices">
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm hover:border-primary/20 transition-colors flex flex-col items-center text-center space-y-3">
              <div className="w-12 h-12 bg-teal-50 rounded-full flex items-center justify-center text-teal-600">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-sm">Full Wash</h4>
                <p className="text-xs text-slate-400 mt-1">Premium detergent</p>
              </div>
            </div>
          </Link>
        </section>

        {/* Info Banner */}
        <div className="text-center pb-8">
          <p className="text-xs text-slate-400 font-medium">
            Al-Shorouk Clean • Trusted by 500+ Neighbors
          </p>
        </div>
      </main>
    </div>
  );
}
