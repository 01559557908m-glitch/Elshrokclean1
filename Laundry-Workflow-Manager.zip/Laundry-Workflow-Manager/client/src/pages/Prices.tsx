import { useState } from "react";
import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useItems } from "@/hooks/use-items";
import { useCreateOrder } from "@/hooks/use-orders";
import { useAuthStore } from "@/hooks/use-auth";
import { Search, Camera, Plus, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Prices() {
  const { data: items, isLoading } = useItems();
  const [search, setSearch] = useState("");
  const { user } = useAuthStore();
  const { toast } = useToast();
  const createOrder = useCreateOrder();
  
  const [isPhotoOpen, setIsPhotoOpen] = useState(false);
  const [note, setNote] = useState("");

  const filteredItems = items?.filter(item => 
    item.name.toLowerCase().includes(search.toLowerCase()) || 
    item.category.toLowerCase().includes(search.toLowerCase())
  );

  const categories = Array.from(new Set(filteredItems?.map(i => i.category) || []));

  const handleSpecialRequest = async () => {
    if (!user) {
      toast({ title: "Login Required", description: "Please login to make a request.", variant: "destructive" });
      return;
    }

    try {
      await createOrder.mutateAsync({
        userId: user.id,
        items: [{
          name: "Special Request (Photo)",
          quantity: 1,
          notes: note,
          imageUrl: "https://images.unsplash.com/photo-1517677208171-0bc5e259b71d?auto=format&fit=crop&w=800&q=80", // Mock image for MVP
        }]
      });
      setIsPhotoOpen(false);
      setNote("");
    } catch (e) {
      // handled in hook
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <main className="mobile-container py-6 space-y-6">
        <div className="space-y-4">
          <h2 className="text-2xl font-display font-bold">Price List</h2>
          
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input 
              placeholder="Search items..." 
              className="pl-10 bg-white border-slate-200"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
          </div>
        ) : (
          <div className="space-y-8">
            {categories.map(category => (
              <section key={category}>
                <h3 className="text-lg font-bold text-slate-700 mb-3">{category}</h3>
                <div className="bg-white rounded-xl shadow-sm border border-slate-100 divide-y divide-slate-50">
                  {filteredItems?.filter(i => i.category === category).map(item => (
                    <div key={item.id} className="p-4 flex justify-between items-center">
                      <div>
                        <p className="font-medium text-slate-900">{item.name}</p>
                        {item.description && (
                          <p className="text-xs text-slate-400 mt-0.5">{item.description}</p>
                        )}
                      </div>
                      <div className="text-primary font-bold font-mono">
                        {item.isVariable ? "On Inspect" : `${item.basePrice} EGP`}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            ))}

            {filteredItems?.length === 0 && (
              <div className="text-center py-12 text-slate-400">
                <p>No items found.</p>
              </div>
            )}
          </div>
        )}

        {/* Special Request FAB */}
        <Dialog open={isPhotoOpen} onOpenChange={setIsPhotoOpen}>
          <DialogTrigger asChild>
            <Button 
              size="lg"
              className="fixed bottom-24 right-4 sm:right-8 rounded-full shadow-lg shadow-primary/30 h-14 px-6 gap-2"
            >
              <Camera className="w-5 h-5" />
              <span>Special Request</span>
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Special Item Request</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="border-2 border-dashed border-slate-200 rounded-xl p-8 flex flex-col items-center justify-center text-slate-400 bg-slate-50">
                <Camera className="w-8 h-8 mb-2" />
                <p className="text-sm">Tap to take photo</p>
                {/* Real file input would go here */}
              </div>
              <Input 
                placeholder="Add notes (e.g., stain on collar)" 
                value={note}
                onChange={(e) => setNote(e.target.value)}
              />
              <Button 
                className="w-full" 
                onClick={handleSpecialRequest}
                disabled={createOrder.isPending}
              >
                {createOrder.isPending ? "Sending..." : "Send Request"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
